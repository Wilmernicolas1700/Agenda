### Agenda
agenda de apuntes
### Resumen de la clase
en la clase pasada aprendimos a activar el modo programador por excel para así comenzar a programar por medio de visual basic con los codigos requeridos para el programa
### Codigos aprendidos
**sud + nombre del rograma** = le da inicio y final al programa  
**Msgbox** = para mostrar el mensaje en la pantalla  
**a** (valor al numerico) asignar un valor a variable
### inicio y final
puedes empezar con sud y para terminar es end sud
### ejemplo
sud ejemplo()  
a = 10  
b = Sofia  
c = Nicolas  
end sud  
